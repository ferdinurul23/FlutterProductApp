
import 'package:flutter/material.dart';

// beberapa referensi kustom warna tambahan
Color dark_background_color = const Color(0XFF191A19);
Color dark_primary_color = const Color(0XFF222831);
Color dark_secondary_color = const Color(0XFF3F4E4F);
Color off_white_color = const Color(0XFFfaf4e1);