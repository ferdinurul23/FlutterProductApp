class PosterData {
  int id;
  String imageAsset;

  PosterData({
    required this.id,
    required this.imageAsset
  });
}

var posterList = [
  PosterData(
      id: 1,
      imageAsset: 'assets/images/img_banner_1.jpg'
  ),
  PosterData(
      id: 2,
      imageAsset: 'assets/images/img_banner_1.jpg'
  ),
  PosterData(
      id: 3,
      imageAsset: 'assets/images/img_banner_1.jpg'
  ),
  PosterData(
      id: 4,
      imageAsset: 'assets/images/img_banner_1.jpg'
  ),
  PosterData(
      id: 5,
      imageAsset: 'assets/images/img_banner_1.jpg'
  ),
  PosterData(
      id: 6,
      imageAsset: 'assets/images/img_banner_1.jpg'
  ),
];