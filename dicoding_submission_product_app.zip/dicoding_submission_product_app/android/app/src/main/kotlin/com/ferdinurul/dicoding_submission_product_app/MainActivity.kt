package com.ferdinurul.dicoding_submission_product_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
